# Supabase Setup Guide

This guide will help you configure Supabase for your Bundle Recommender application.

## Prerequisites

- A Supabase account (sign up at https://supabase.com)
- Your Supabase project credentials (already configured in `.env`)

## Authentication Configuration

### 1. Configure Site URL and Redirect URLs

This is **CRITICAL** for the magic link authentication to work properly.

1. Go to your Supabase Dashboard: https://supabase.com/dashboard
2. Select your project
3. Navigate to **Authentication** → **URL Configuration**
4. Configure the following:

**For Development:**
- **Site URL**: `http://localhost:5173`
- **Redirect URLs**: Add these URLs (one per line):
  ```
  http://localhost:5173/**
  http://localhost:5173/reset-password
  ```

**For Production (after deployment):**
- **Site URL**: `https://your-deployed-app.com`
- **Redirect URLs**: Add these URLs:
  ```
  https://your-deployed-app.com/**
  https://your-deployed-app.com/reset-password
  ```

### 2. Email Provider Settings

1. Go to **Authentication** → **Providers**
2. Make sure **Email** is enabled
3. Click on **Email** to configure:
   - **Enable Email provider**: ✓ Checked
   - **Confirm email**: ✓ Checked (recommended)
   - **Secure email change**: ✓ Checked (recommended)

### 3. Email Templates (Optional Customization)

You can customize the email templates sent to users:

1. Go to **Authentication** → **Email Templates**
2. You'll find templates for:
   - **Confirm signup**: Email sent when users register
   - **Magic Link**: Email sent for passwordless login
   - **Change Email Address**: Email sent when changing email
   - **Reset Password**: Email sent for password reset

**Default templates work fine**, but you can customize them with your branding.

## How Magic Link Authentication Works

### Registration Flow:
1. User fills in name, email, and password
2. Clicks "Register"
3. Receives an email with a confirmation link
4. Clicks the link in the email
5. **Automatically logged in** and redirected to the dashboard

### Login Flow:
1. User enters email and password
2. If email is verified, logs in immediately
3. If email is not verified, shows error message

### Password Reset Flow:
1. User clicks "Forgot password?"
2. Enters their email
3. Receives an email with a reset link
4. Clicks the link
5. Redirected to reset password page
6. Sets new password and logs in

## Testing the Authentication

### Test Registration:
```bash
# Start the dev server
pnpm run dev

# Open http://localhost:5173
# Go to Register tab
# Fill in: Name, Email, Password
# Click Register
# Check your email for confirmation link
# Click the link - you'll be logged in automatically!
```

### Test Login:
```bash
# After confirming your email
# Go to Login tab
# Enter your email and password
# Click Login
```

### Test Password Reset:
```bash
# On login page, click "Forgot password?"
# Enter your email
# Check email for reset link
# Click link and set new password
```

## Troubleshooting

### "Invalid Redirect URL" Error
- Make sure you've added the correct URLs in **Authentication** → **URL Configuration**
- The redirect URLs must include `/**` wildcard for development
- Wait a few minutes after saving changes for them to take effect

### Email Not Received
- Check your spam/junk folder
- Verify the email provider is enabled in Supabase
- Check Supabase logs: **Authentication** → **Logs**

### "Email not confirmed" Error
- User needs to click the confirmation link in their email first
- Check if the email was sent in Supabase logs
- Resend confirmation email if needed

### Link Doesn't Work
- Verify Site URL matches your development URL exactly
- Make sure redirect URLs are configured correctly
- Clear browser cache and try again

## Security Best Practices

1. **Never commit `.env` file** to version control
2. **Use different Supabase projects** for development and production
3. **Enable Row Level Security (RLS)** when you migrate to database storage
4. **Rotate API keys** if they're ever exposed
5. **Use environment variables** for all sensitive data

## Next Steps

Once authentication is working:

1. **Test all flows** (register, login, password reset)
2. **Migrate data storage** from localStorage to Supabase database
3. **Set up Row Level Security** policies for user data
4. **Deploy to production** and update Supabase URLs

## Support

If you encounter issues:
- Check Supabase documentation: https://supabase.com/docs
- Review Supabase logs in your dashboard
- Verify all configuration settings match this guide