import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || '';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || '';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export interface User {
  id: string;
  email: string;
  name: string;
}

// Auth functions with Supabase
export const signUpWithEmail = async (email: string, password: string, name: string) => {
  // Try to sign up
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
    options: {
      data: {
        name,
      },
      emailRedirectTo: `${window.location.origin}/dashboard`,
    },
  });

  if (error) {
    // Check if it's a duplicate user error
    if (error.message.includes('already registered') || 
        error.message.includes('User already registered') ||
        error.message.includes('duplicate')) {
      throw new Error('This email is already registered. Please login instead.');
    }
    throw error;
  }

  // Additional check: if user was created but identities is empty, it might be a duplicate
  if (data.user && data.user.identities && data.user.identities.length === 0) {
    throw new Error('This email is already registered. Please login instead.');
  }

  // Store user info in localStorage immediately
  if (data.user) {
    localStorage.setItem('userEmail', data.user.email || '');
    localStorage.setItem('displayName', data.user.user_metadata?.name || data.user.email?.split('@')[0] || '');
    localStorage.setItem('joinDate', data.user.created_at || new Date().toISOString());
  }

  return data;
};

export const verifyOtp = async (email: string, token: string) => {
  const { data, error } = await supabase.auth.verifyOtp({
    email,
    token,
    type: 'email',
  });

  if (error) throw error;
  return data;
};

export const signInWithEmail = async (email: string, password: string) => {
  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password,
  });

  if (error) throw error;
  
  // Store user info in localStorage for the app
  if (data.user) {
    localStorage.setItem('userEmail', data.user.email || '');
    localStorage.setItem('displayName', data.user.user_metadata?.name || data.user.email?.split('@')[0] || '');
    localStorage.setItem('joinDate', data.user.created_at || new Date().toISOString());
  }
  
  return data;
};

export const signOut = async () => {
  // Clear localStorage on logout
  localStorage.removeItem('userEmail');
  localStorage.removeItem('displayName');
  localStorage.removeItem('joinDate');
  
  const { error } = await supabase.auth.signOut();
  if (error) throw error;
};

export const resetPasswordForEmail = async (email: string) => {
  const { data, error } = await supabase.auth.resetPasswordForEmail(email, {
    redirectTo: `${window.location.origin}/reset-password`,
  });

  if (error) throw error;
  return data;
};

export const updatePassword = async (newPassword: string) => {
  const { data, error } = await supabase.auth.updateUser({
    password: newPassword,
  });

  if (error) throw error;
  return data;
};

export const getCurrentUser = async (): Promise<User | null> => {
  const { data: { user } } = await supabase.auth.getUser();
  
  if (!user) return null;
  
  // Store user info in localStorage
  localStorage.setItem('userEmail', user.email || '');
  localStorage.setItem('displayName', user.user_metadata?.name || user.email?.split('@')[0] || '');
  localStorage.setItem('joinDate', user.created_at || new Date().toISOString());
  
  return {
    id: user.id,
    email: user.email || '',
    name: user.user_metadata?.name || '',
  };
};

export const onAuthStateChange = (callback: (user: User | null) => void) => {
  return supabase.auth.onAuthStateChange(async (event, session) => {
    if (session?.user) {
      // Store user info in localStorage
      localStorage.setItem('userEmail', session.user.email || '');
      localStorage.setItem('displayName', session.user.user_metadata?.name || session.user.email?.split('@')[0] || '');
      localStorage.setItem('joinDate', session.user.created_at || new Date().toISOString());
      
      const user: User = {
        id: session.user.id,
        email: session.user.email || '',
        name: session.user.user_metadata?.name || '',
      };
      callback(user);
    } else {
      callback(null);
    }
  });
};