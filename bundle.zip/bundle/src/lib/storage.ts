// Local storage utility for managing app data
export interface User {
  id: string;
  email: string;
  name: string;
}

export interface SalesReport {
  id: string;
  userId: string;
  fileName: string;
  uploadDate: string;
  data: SalesData[];
  columnMapping?: ColumnMapping;
}

export interface ColumnMapping {
  receiptId: string;
  product: string;
  category: string;
  quantity: string;
  price: string;
  date: string;
}

export interface SalesData {
  receiptId: string;
  product: string;
  category: string;
  quantity: number;
  price: number;
  date: string;
}

export interface Bundle {
  id: string;
  userId: string;
  bundleName: string;
  items: BundleItem[];
  totalPrice: number;
  coPurchasePercentage: number;
  createdDate: string;
}

export interface BundleItem {
  product: string;
  category: string;
  price: number;
}

export interface CategoryConfig {
  category: string;
  productCount: number;
}

// Auth functions
export const getCurrentUser = (): User | null => {
  const userStr = localStorage.getItem('currentUser');
  return userStr ? JSON.parse(userStr) : null;
};

export const setCurrentUser = (user: User | null) => {
  if (user) {
    localStorage.setItem('currentUser', JSON.stringify(user));
  } else {
    localStorage.removeItem('currentUser');
  }
};

export const login = (email: string, password: string): User | null => {
  const users = getUsers();
  const user = users.find(u => u.email === email);
  
  if (user) {
    // In real app, verify password hash
    setCurrentUser(user);
    return user;
  }
  return null;
};

export const register = (email: string, password: string, name: string): User => {
  const users = getUsers();
  const newUser: User = {
    id: Date.now().toString(),
    email,
    name
  };
  users.push(newUser);
  localStorage.setItem('users', JSON.stringify(users));
  setCurrentUser(newUser);
  return newUser;
};

export const logout = () => {
  setCurrentUser(null);
};

const getUsers = (): User[] => {
  const usersStr = localStorage.getItem('users');
  return usersStr ? JSON.parse(usersStr) : [];
};

// Sales Reports functions
export const getSalesReports = (userId: string): SalesReport[] => {
  const reportsStr = localStorage.getItem('salesReports');
  const reports: SalesReport[] = reportsStr ? JSON.parse(reportsStr) : [];
  return reports.filter(r => r.userId === userId);
};

export const addSalesReport = (report: SalesReport) => {
  const reportsStr = localStorage.getItem('salesReports');
  const reports: SalesReport[] = reportsStr ? JSON.parse(reportsStr) : [];
  reports.push(report);
  localStorage.setItem('salesReports', JSON.stringify(reports));
};

export const deleteSalesReport = (reportId: string) => {
  const reportsStr = localStorage.getItem('salesReports');
  const reports: SalesReport[] = reportsStr ? JSON.parse(reportsStr) : [];
  const filtered = reports.filter(r => r.id !== reportId);
  localStorage.setItem('salesReports', JSON.stringify(filtered));
};

// Bundles functions
export const getBundles = (userId: string): Bundle[] => {
  const bundlesStr = localStorage.getItem('bundles');
  const bundles: Bundle[] = bundlesStr ? JSON.parse(bundlesStr) : [];
  return bundles.filter(b => b.userId === userId);
};

export const addBundle = (bundle: Bundle) => {
  const bundlesStr = localStorage.getItem('bundles');
  const bundles: Bundle[] = bundlesStr ? JSON.parse(bundlesStr) : [];
  bundles.push(bundle);
  localStorage.setItem('bundles', JSON.stringify(bundles));
};

export const deleteBundle = (bundleId: string) => {
  const bundlesStr = localStorage.getItem('bundles');
  const bundles: Bundle[] = bundlesStr ? JSON.parse(bundlesStr) : [];
  const filtered = bundles.filter(b => b.id !== bundleId);
  localStorage.setItem('bundles', JSON.stringify(filtered));
};

// Get all unique categories from sales data
export const getCategories = (userId: string): string[] => {
  const reports = getSalesReports(userId);
  const categories = new Set<string>();
  reports.forEach(report => {
    report.data.forEach(item => {
      if (item.category) {
        categories.add(item.category);
      }
    });
  });
  return Array.from(categories).sort();
};