import { supabase } from './supabase';
import { SalesReport, SavedBundle } from './storage';

const SALES_REPORTS_TABLE = 'app_1583311cb5_sales_reports';
const BUNDLES_TABLE = 'app_1583311cb5_bundles';

// Sales Reports Functions
export async function saveSalesReportToSupabase(report: SalesReport): Promise<void> {
  const { error } = await supabase
    .from(SALES_REPORTS_TABLE)
    .insert({
      id: report.id,
      user_id: report.userId,
      file_name: report.fileName,
      upload_date: report.uploadDate,
      data: report.data,
    });

  if (error) {
    console.error('Error saving sales report:', error);
    throw new Error('Failed to save sales report to database');
  }
}

export async function getSalesReportsFromSupabase(userId: string): Promise<SalesReport[]> {
  const { data, error } = await supabase
    .from(SALES_REPORTS_TABLE)
    .select('*')
    .eq('user_id', userId)
    .order('upload_date', { ascending: false });

  if (error) {
    console.error('Error fetching sales reports:', error);
    throw new Error('Failed to fetch sales reports from database');
  }

  return (data || []).map(row => ({
    id: row.id,
    userId: row.user_id,
    fileName: row.file_name,
    uploadDate: row.upload_date,
    data: row.data,
  }));
}

export async function deleteSalesReportFromSupabase(reportId: string): Promise<void> {
  const { error } = await supabase
    .from(SALES_REPORTS_TABLE)
    .delete()
    .eq('id', reportId);

  if (error) {
    console.error('Error deleting sales report:', error);
    throw new Error('Failed to delete sales report from database');
  }
}

// Bundles Functions
export async function saveBundleToSupabase(bundle: SavedBundle): Promise<void> {
  const { error } = await supabase
    .from(BUNDLES_TABLE)
    .insert({
      id: bundle.id,
      user_id: bundle.userId,
      bundle_name: bundle.bundleName,
      items: bundle.items,
      total_price: bundle.totalPrice,
      co_purchase_percentage: bundle.coPurchasePercentage,
      created_date: bundle.createdDate,
    });

  if (error) {
    console.error('Error saving bundle:', error);
    throw new Error('Failed to save bundle to database');
  }
}

export async function getBundlesFromSupabase(userId: string): Promise<SavedBundle[]> {
  const { data, error } = await supabase
    .from(BUNDLES_TABLE)
    .select('*')
    .eq('user_id', userId)
    .order('created_date', { ascending: false });

  if (error) {
    console.error('Error fetching bundles:', error);
    throw new Error('Failed to fetch bundles from database');
  }

  return (data || []).map(row => ({
    id: row.id,
    userId: row.user_id,
    bundleName: row.bundle_name,
    items: row.items,
    totalPrice: parseFloat(row.total_price),
    coPurchasePercentage: parseFloat(row.co_purchase_percentage),
    createdDate: row.created_date,
  }));
}

export async function deleteBundleFromSupabase(bundleId: string): Promise<void> {
  const { error } = await supabase
    .from(BUNDLES_TABLE)
    .delete()
    .eq('id', bundleId);

  if (error) {
    console.error('Error deleting bundle:', error);
    throw new Error('Failed to delete bundle from database');
  }
}

// Migration helper: Move data from localStorage to Supabase
export async function migrateLocalStorageToSupabase(userId: string): Promise<{ reports: number; bundles: number }> {
  let migratedReports = 0;
  let migratedBundles = 0;

  try {
    // Migrate sales reports
    const reportsStr = localStorage.getItem('salesReports');
    if (reportsStr) {
      const reports: SalesReport[] = JSON.parse(reportsStr);
      const userReports = reports.filter(r => r.userId === userId);
      
      for (const report of userReports) {
        try {
          await saveSalesReportToSupabase(report);
          migratedReports++;
        } catch (error) {
          console.error('Error migrating report:', report.id, error);
        }
      }
    }

    // Migrate bundles
    const bundlesStr = localStorage.getItem('bundles');
    if (bundlesStr) {
      const bundles: SavedBundle[] = JSON.parse(bundlesStr);
      const userBundles = bundles.filter(b => b.userId === userId);
      
      for (const bundle of userBundles) {
        try {
          await saveBundleToSupabase(bundle);
          migratedBundles++;
        } catch (error) {
          console.error('Error migrating bundle:', bundle.id, error);
        }
      }
    }

    return { reports: migratedReports, bundles: migratedBundles };
  } catch (error) {
    console.error('Migration error:', error);
    throw new Error('Failed to migrate data from localStorage to Supabase');
  }
}