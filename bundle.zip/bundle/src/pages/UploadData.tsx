import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { SalesData, ColumnMapping } from '@/lib/storage';
import { getCurrentUser } from '@/lib/supabase';
import { saveSalesReportToSupabase, getSalesReportsFromSupabase, deleteSalesReportFromSupabase } from '@/lib/supabase-storage';
import { Upload, Trash2, FileSpreadsheet, Settings, Download, Package, Layers, AlertTriangle } from 'lucide-react';
import { toast } from 'sonner';

interface SalesReport {
  id: string;
  userId: string;
  fileName: string;
  uploadDate: string;
  data: SalesData[];
  columnMapping?: ColumnMapping;
}

export default function UploadData() {
  const [user, setUser] = useState<{ id: string; email: string } | null>(null);
  const [loading, setLoading] = useState(true);
  const [reports, setReports] = useState<SalesReport[]>([]);
  const [uploading, setUploading] = useState(false);
  const [showMappingDialog, setShowMappingDialog] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [reportToDelete, setReportToDelete] = useState<{ id: string; name: string } | null>(null);
  const [pendingFile, setPendingFile] = useState<File | null>(null);
  const [csvHeaders, setCsvHeaders] = useState<string[]>([]);
  const [columnMapping, setColumnMapping] = useState<ColumnMapping>({
    receiptId: '',
    product: '',
    category: '',
    quantity: '',
    price: '',
    date: '',
  });

  useEffect(() => {
    // Load user from Supabase
    const loadUser = async () => {
      const currentUser = await getCurrentUser();
      setUser(currentUser);
      if (currentUser) {
        await loadReports(currentUser.id);
      }
      setLoading(false);
    };
    loadUser();
  }, []);

  const loadReports = async (userId: string) => {
    try {
      const supabaseReports = await getSalesReportsFromSupabase(userId);
      setReports(supabaseReports);
    } catch (error) {
      console.error('Error loading reports:', error);
      toast.error('Failed to load reports from database');
    }
  };

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!user) {
      toast.error('Please login to upload files');
      return;
    }

    try {
      const text = await file.text();
      const lines = text.split('\n').filter(line => line.trim());
      const headers = lines[0].split(',').map(h => h.trim());
      
      setCsvHeaders(headers);
      setPendingFile(file);
      setColumnMapping({
        receiptId: '',
        product: '',
        category: '',
        quantity: '',
        price: '',
        date: '',
      });
      setShowMappingDialog(true);
    } catch (error) {
      toast.error('Failed to read file');
    }
    e.target.value = '';
  };

  const handleUpload = async () => {
    if (!pendingFile || !user) return;

    // Validate mapping
    if (!columnMapping.receiptId || !columnMapping.product || !columnMapping.category || !columnMapping.quantity || !columnMapping.price) {
      toast.error('Please map all required columns');
      return;
    }

    setUploading(true);
    try {
      const text = await pendingFile.text();
      const lines = text.split('\n').filter(line => line.trim());
      const headers = lines[0].split(',').map(h => h.trim());
      
      const getIndex = (mapping: string) => headers.findIndex(h => h === mapping);
      
      const data: SalesData[] = [];
      for (let i = 1; i < lines.length; i++) {
        const values = lines[i].split(',').map(v => v.trim());
        if (values.length >= 5) {
          data.push({
            receiptId: values[getIndex(columnMapping.receiptId)] || '',
            product: values[getIndex(columnMapping.product)] || '',
            category: values[getIndex(columnMapping.category)] || '',
            quantity: parseInt(values[getIndex(columnMapping.quantity)]) || 0,
            price: parseFloat(values[getIndex(columnMapping.price)]) || 0,
            date: values[getIndex(columnMapping.date)] || new Date().toISOString().split('T')[0],
          });
        }
      }

      const newReport: SalesReport = {
        id: Date.now().toString(),
        userId: user.id,
        fileName: pendingFile.name,
        uploadDate: new Date().toISOString(),
        data,
        columnMapping,
      };

      // Save to Supabase
      await saveSalesReportToSupabase(newReport);
      await loadReports(user.id);
      
      toast.success('Sales report uploaded successfully!');
      setShowMappingDialog(false);
      setPendingFile(null);
    } catch (error) {
      console.error('Upload error:', error);
      toast.error('Failed to upload file. Please try again.');
    } finally {
      setUploading(false);
    }
  };

  const handleDeleteClick = (reportId: string, fileName: string) => {
    setReportToDelete({ id: reportId, name: fileName });
    setShowDeleteDialog(true);
  };

  const confirmDelete = async () => {
    if (!reportToDelete || !user) return;

    try {
      await deleteSalesReportFromSupabase(reportToDelete.id);
      await loadReports(user.id);
      toast.success('Report deleted successfully');
    } catch (error) {
      console.error('Delete error:', error);
      toast.error('Failed to delete report');
    } finally {
      setShowDeleteDialog(false);
      setReportToDelete(null);
    }
  };

  const downloadReport = (reportId: string) => {
    const report = reports.find(r => r.id === reportId);
    if (!report) return;

    // Convert data back to CSV
    const headers = ['Receipt ID', 'Product', 'Category', 'Quantity', 'Price', 'Date'];
    const csvContent = [
      headers.join(','),
      ...report.data.map(item => 
        [item.receiptId, item.product, item.category, item.quantity, item.price, item.date].join(',')
      )
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = report.fileName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    toast.success(`Downloaded ${report.fileName}`);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold bg-gradient-to-r from-green-600 to-emerald-600 bg-clip-text text-transparent">
          Upload Sales Data
        </h2>
        <p className="text-gray-600 mt-2">Import your sales receipts to analyze co-purchase patterns</p>
      </div>

      <Card className="border-2 border-green-200 bg-gradient-to-br from-green-50 to-emerald-50">
        <CardHeader className="bg-gradient-to-r from-green-600 to-emerald-600 text-white rounded-t-lg">
          <CardTitle className="flex items-center gap-2">
            <Upload className="h-5 w-5" />
            Upload CSV File
          </CardTitle>
          <CardDescription className="text-green-100">
            Upload a CSV file with receipt-level transaction data. You'll map the columns in the next step.
          </CardDescription>
        </CardHeader>
        <CardContent className="pt-6">
          <div className="flex items-center gap-4">
            <Input
              type="file"
              accept=".csv"
              onChange={handleFileSelect}
              disabled={uploading}
              className="max-w-md border-green-300 focus:border-green-500"
            />
          </div>
          <div className="mt-4 p-4 bg-blue-50 border-2 border-blue-200 rounded-lg">
            <h4 className="font-semibold text-sm mb-2 text-blue-900 flex items-center gap-2">
              <Layers className="h-4 w-4" />
              Required Data:
            </h4>
            <ul className="text-xs text-blue-800 space-y-1">
              <li>• Receipt ID (to identify products bought together)</li>
              <li>• Product Name</li>
              <li>• Product Category</li>
              <li>• Quantity Sold</li>
              <li>• Price per Unit</li>
              <li>• Date (optional)</li>
            </ul>
          </div>
        </CardContent>
      </Card>

      <Card className="border-2 border-purple-200 bg-gradient-to-br from-purple-50 to-pink-50">
        <CardHeader className="bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-t-lg">
          <CardTitle className="flex items-center gap-2">
            <FileSpreadsheet className="h-5 w-5" />
            Uploaded Reports
          </CardTitle>
          <CardDescription className="text-purple-100">
            Manage your sales data files
          </CardDescription>
        </CardHeader>
        <CardContent className="pt-6">
          {reports.length === 0 ? (
            <div className="text-center py-12 text-gray-500">
              <FileSpreadsheet className="h-12 w-12 mx-auto mb-4 text-gray-400" />
              <p className="font-semibold">No reports uploaded yet</p>
              <p className="text-sm">Upload a CSV file to get started</p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="font-bold">File Name</TableHead>
                  <TableHead className="font-bold">Upload Date</TableHead>
                  <TableHead className="font-bold">Receipts</TableHead>
                  <TableHead className="font-bold">Products</TableHead>
                  <TableHead className="font-bold">Categories</TableHead>
                  <TableHead className="text-right font-bold">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {reports.map((report) => (
                  <TableRow key={report.id} className="hover:bg-purple-100">
                    <TableCell className="font-medium">{report.fileName}</TableCell>
                    <TableCell>{new Date(report.uploadDate).toLocaleDateString()}</TableCell>
                    <TableCell>
                      <Badge className="bg-blue-100 text-blue-700">
                        <Package className="h-3 w-3 mr-1" />
                        {new Set(report.data.map(d => d.receiptId)).size}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge className="bg-green-100 text-green-700">
                        {new Set(report.data.map(d => d.product)).size}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge className="bg-orange-100 text-orange-700">
                        {new Set(report.data.map(d => d.category)).size}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => downloadReport(report.id)}
                          className="text-green-600 hover:text-green-700 hover:bg-green-100"
                        >
                          <Download className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDeleteClick(report.id, report.fileName)}
                          className="text-red-600 hover:text-red-700 hover:bg-red-100"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Column Mapping Dialog */}
      <Dialog open={showMappingDialog} onOpenChange={setShowMappingDialog}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-purple-900">
              <Settings className="h-5 w-5" />
              Map CSV Columns
            </DialogTitle>
            <DialogDescription>
              Match your CSV columns to the required fields
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Receipt ID Column <span className="text-red-500">*</span></Label>
              <select
                className="w-full p-2 border-2 border-purple-300 rounded-md focus:border-purple-500 focus:outline-none"
                value={columnMapping.receiptId}
                onChange={(e) => setColumnMapping({...columnMapping, receiptId: e.target.value})}
              >
                <option value="">Select column...</option>
                {csvHeaders.map(header => (
                  <option key={header} value={header}>{header}</option>
                ))}
              </select>
            </div>

            <div className="space-y-2">
              <Label>Product Name Column <span className="text-red-500">*</span></Label>
              <select
                className="w-full p-2 border-2 border-purple-300 rounded-md focus:border-purple-500 focus:outline-none"
                value={columnMapping.product}
                onChange={(e) => setColumnMapping({...columnMapping, product: e.target.value})}
              >
                <option value="">Select column...</option>
                {csvHeaders.map(header => (
                  <option key={header} value={header}>{header}</option>
                ))}
              </select>
            </div>

            <div className="space-y-2">
              <Label>Category Column <span className="text-red-500">*</span></Label>
              <select
                className="w-full p-2 border-2 border-purple-300 rounded-md focus:border-purple-500 focus:outline-none"
                value={columnMapping.category}
                onChange={(e) => setColumnMapping({...columnMapping, category: e.target.value})}
              >
                <option value="">Select column...</option>
                {csvHeaders.map(header => (
                  <option key={header} value={header}>{header}</option>
                ))}
              </select>
            </div>

            <div className="space-y-2">
              <Label>Quantity Column <span className="text-red-500">*</span></Label>
              <select
                className="w-full p-2 border-2 border-purple-300 rounded-md focus:border-purple-500 focus:outline-none"
                value={columnMapping.quantity}
                onChange={(e) => setColumnMapping({...columnMapping, quantity: e.target.value})}
              >
                <option value="">Select column...</option>
                {csvHeaders.map(header => (
                  <option key={header} value={header}>{header}</option>
                ))}
              </select>
            </div>

            <div className="space-y-2">
              <Label>Price Column <span className="text-red-500">*</span></Label>
              <select
                className="w-full p-2 border-2 border-purple-300 rounded-md focus:border-purple-500 focus:outline-none"
                value={columnMapping.price}
                onChange={(e) => setColumnMapping({...columnMapping, price: e.target.value})}
              >
                <option value="">Select column...</option>
                {csvHeaders.map(header => (
                  <option key={header} value={header}>{header}</option>
                ))}
              </select>
            </div>

            <div className="space-y-2">
              <Label>Date Column (Optional)</Label>
              <select
                className="w-full p-2 border-2 border-purple-300 rounded-md focus:border-purple-500 focus:outline-none"
                value={columnMapping.date}
                onChange={(e) => setColumnMapping({...columnMapping, date: e.target.value})}
              >
                <option value="">Select column...</option>
                {csvHeaders.map(header => (
                  <option key={header} value={header}>{header}</option>
                ))}
              </select>
            </div>
          </div>

          <DialogFooter className="sticky bottom-0 bg-white pt-4 border-t">
            <Button variant="outline" onClick={() => setShowMappingDialog(false)}>
              Cancel
            </Button>
            <Button 
              onClick={handleUpload} 
              disabled={uploading}
              className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
            >
              <Upload className="mr-2 h-4 w-4" />
              {uploading ? 'Uploading...' : 'Upload'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2 text-red-600">
              <AlertTriangle className="h-5 w-5" />
              Delete Sales Report
            </AlertDialogTitle>
            <AlertDialogDescription className="space-y-2">
              <p>Are you sure you want to delete this report?</p>
              {reportToDelete && (
                <p className="font-semibold text-gray-900">"{reportToDelete.name}"</p>
              )}
              <p className="text-red-600">This action cannot be undone. All data in this report will be permanently deleted.</p>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setReportToDelete(null)}>
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDelete}
              className="bg-red-600 hover:bg-red-700 focus:ring-red-600"
            >
              <Trash2 className="mr-2 h-4 w-4" />
              Delete Report
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}