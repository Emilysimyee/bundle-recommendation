import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import { Upload, Download, FileText, Database } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

export default function DashboardHome() {
  const navigate = useNavigate();

  const stats = [
    { label: 'Datasets Uploaded', value: '0', icon: Database, color: 'from-blue-500 to-cyan-500' },
    { label: 'Bundles Generated', value: '0', icon: Database, color: 'from-purple-500 to-pink-500' },
    { label: 'Reports Exported', value: '0', icon: FileText, color: 'from-green-500 to-emerald-500' },
  ];

  return (
    <div className="space-y-8">
      {/* Welcome Section */}
      <div className="bg-gradient-to-r from-purple-600 via-pink-600 to-orange-500 rounded-lg p-8 text-white shadow-xl">
        <h1 className="text-3xl font-bold mb-2">Welcome to Bundle Recommender! 🎉</h1>
        <p className="text-lg opacity-90">
          Create intelligent product bundles based on customer purchase patterns
        </p>
      </div>

      {/* Getting Started Guide */}
      <Card className="border-2 border-blue-200 shadow-lg">
        <CardHeader className="bg-gradient-to-r from-blue-100 to-cyan-100">
          <CardTitle>Getting Started Guide</CardTitle>
          <CardDescription>Follow these steps to create your first bundle</CardDescription>
        </CardHeader>
        <CardContent className="pt-6">
          <ol className="space-y-4">
            <li className="flex items-start gap-3">
              <Badge className="bg-gradient-to-r from-green-500 to-emerald-500 text-white shrink-0">1</Badge>
              <div>
                <p className="font-semibold text-gray-900">Upload Your Data</p>
                <p className="text-sm text-gray-600">
                  Upload receipt data, product information, and category configurations. You can use our sample data to get started quickly.
                </p>
              </div>
            </li>
            <li className="flex items-start gap-3">
              <Badge className="bg-gradient-to-r from-purple-500 to-pink-500 text-white shrink-0">2</Badge>
              <div>
                <p className="font-semibold text-gray-900">Generate Bundles</p>
                <p className="text-sm text-gray-600">
                  Select your datasets and let our algorithm create intelligent product bundles based on purchase patterns.
                </p>
              </div>
            </li>
            <li className="flex items-start gap-3">
              <Badge className="bg-gradient-to-r from-orange-500 to-red-500 text-white shrink-0">3</Badge>
              <div>
                <p className="font-semibold text-gray-900">Analyze Results</p>
                <p className="text-sm text-gray-600">
                  View analytics and insights about your bundles, including category distribution and performance metrics.
                </p>
              </div>
            </li>
            <li className="flex items-start gap-3">
              <Badge className="bg-gradient-to-r from-indigo-500 to-blue-500 text-white shrink-0">4</Badge>
              <div>
                <p className="font-semibold text-gray-900">Export & Use</p>
                <p className="text-sm text-gray-600">
                  Download your bundle recommendations as CSV files for easy integration with your systems.
                </p>
              </div>
            </li>
          </ol>
        </CardContent>
      </Card>

      {/* Sample Data Section */}
      <Card className="border-2 border-purple-200 shadow-lg">
        <CardHeader className="bg-gradient-to-r from-purple-100 to-pink-100">
          <CardTitle className="flex items-center gap-2">
            <Database className="h-5 w-5 text-purple-600" />
            Sample Data Available
          </CardTitle>
          <CardDescription>
            Get started quickly with our pre-loaded sample dataset
          </CardDescription>
        </CardHeader>
        <CardContent className="pt-6">
          <div className="space-y-4">
            <p className="text-gray-700">
              We've prepared sample data files for you to test the bundle generator:
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                <div className="flex items-center gap-2 mb-2">
                  <FileText className="h-4 w-4 text-blue-600" />
                  <span className="font-semibold text-blue-900">Receipts Data</span>
                </div>
                <p className="text-sm text-gray-600">35 transactions with customer purchases</p>
                <Badge className="mt-2 bg-blue-500">15 receipts</Badge>
              </div>
              <div className="p-4 bg-green-50 rounded-lg border border-green-200">
                <div className="flex items-center gap-2 mb-2">
                  <FileText className="h-4 w-4 text-green-600" />
                  <span className="font-semibold text-green-900">Products Data</span>
                </div>
                <p className="text-sm text-gray-600">20 products across 10 categories</p>
                <Badge className="mt-2 bg-green-500">20 products</Badge>
              </div>
              <div className="p-4 bg-purple-50 rounded-lg border border-purple-200">
                <div className="flex items-center gap-2 mb-2">
                  <FileText className="h-4 w-4 text-purple-600" />
                  <span className="font-semibold text-purple-900">Categories Config</span>
                </div>
                <p className="text-sm text-gray-600">Bundle rules for each category</p>
                <Badge className="mt-2 bg-purple-500">10 categories</Badge>
              </div>
            </div>
            <div className="flex gap-3 pt-2">
              <Button
                onClick={() => navigate('/dashboard/upload')}
                className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
              >
                <Upload className="h-4 w-4 mr-2" />
                Upload Sample Data
              </Button>
              <Button
                variant="outline"
                onClick={() => {
                  const link = document.createElement('a');
                  link.href = '/sample-data/sample_receipts.csv';
                  link.download = 'sample_receipts.csv';
                  link.click();
                }}
              >
                <Download className="h-4 w-4 mr-2" />
                Download Samples
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {stats.map((stat, index) => (
          <Card key={index} className="border-2 shadow-lg hover:shadow-xl transition-shadow">
            <CardHeader className={`bg-gradient-to-r ${stat.color} text-white rounded-t-lg`}>
              <CardTitle className="flex items-center justify-between">
                <span className="text-lg">{stat.label}</span>
                <stat.icon className="h-6 w-6" />
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-6">
              <p className="text-4xl font-bold text-gray-900">{stat.value}</p>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}