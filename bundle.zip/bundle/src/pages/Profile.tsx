import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import { User, Mail, Calendar, Shield, Database, Download, Save, X } from 'lucide-react';
import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';

export default function Profile() {
  const navigate = useNavigate();
  const [isEditing, setIsEditing] = useState(false);
  const [displayName, setDisplayName] = useState('');
  const [tempDisplayName, setTempDisplayName] = useState('');
  const [userEmail, setUserEmail] = useState('');
  const [joinDate, setJoinDate] = useState('');

  useEffect(() => {
    // Load user data from localStorage
    const email = localStorage.getItem('userEmail') || 'user@example.com';
    const name = localStorage.getItem('displayName') || email.split('@')[0];
    const joined = localStorage.getItem('joinDate') || new Date().toISOString().split('T')[0];
    
    setUserEmail(email);
    setDisplayName(name);
    setTempDisplayName(name);
    setJoinDate(joined);
  }, []);

  const handleSaveDisplayName = () => {
    localStorage.setItem('displayName', tempDisplayName);
    setDisplayName(tempDisplayName);
    setIsEditing(false);
    toast.success('Display name updated successfully');
    // Trigger a navigation to refresh the dashboard
    window.dispatchEvent(new Event('storage'));
  };

  const handleCancelEdit = () => {
    setTempDisplayName(displayName);
    setIsEditing(false);
  };

  const handleExportData = () => {
    // Export all user data
    const data = {
      email: userEmail,
      displayName: displayName,
      joinDate: joinDate,
      receipts: JSON.parse(localStorage.getItem('receipts') || '[]'),
      products: JSON.parse(localStorage.getItem('products') || '[]'),
      categories: JSON.parse(localStorage.getItem('categories') || '[]'),
      bundles: JSON.parse(localStorage.getItem('bundles') || '[]'),
    };

    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `bundle-recommender-data-${new Date().toISOString().split('T')[0]}.json`;
    link.click();
    URL.revokeObjectURL(url);
    toast.success('Data exported successfully');
  };

  const getUserInitials = (name: string) => {
    return name.substring(0, 2).toUpperCase();
  };

  const calculateStorageUsage = () => {
    const receipts = JSON.parse(localStorage.getItem('receipts') || '[]').length;
    const products = JSON.parse(localStorage.getItem('products') || '[]').length;
    const categories = JSON.parse(localStorage.getItem('categories') || '[]').length;
    const bundles = JSON.parse(localStorage.getItem('bundles') || '[]').length;
    const total = receipts + products + categories + bundles;
    const maxStorage = 1000; // Arbitrary limit for demo
    return Math.min((total / maxStorage) * 100, 100);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
          Profile Settings
        </h1>
        <p className="text-gray-600 mt-2">Manage your account information and preferences</p>
      </div>

      {/* Profile Information Card */}
      <Card className="border-2 border-purple-200 shadow-lg">
        <CardHeader className="bg-gradient-to-r from-purple-100 to-pink-100">
          <CardTitle className="flex items-center gap-2">
            <User className="h-5 w-5 text-purple-600" />
            Profile Information
          </CardTitle>
          <CardDescription>Your personal details and account information</CardDescription>
        </CardHeader>
        <CardContent className="pt-6 space-y-6">
          {/* Avatar and Display Name */}
          <div className="flex items-start gap-6">
            <Avatar className="h-24 w-24 bg-gradient-to-br from-purple-600 to-pink-600">
              <AvatarFallback className="bg-transparent text-white text-2xl font-bold">
                {getUserInitials(displayName)}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1 space-y-4">
              <div>
                <Label htmlFor="displayName">Display Name</Label>
                {isEditing ? (
                  <div className="flex gap-2 mt-2">
                    <Input
                      id="displayName"
                      value={tempDisplayName}
                      onChange={(e) => setTempDisplayName(e.target.value)}
                      className="flex-1"
                    />
                    <Button
                      onClick={handleSaveDisplayName}
                      className="bg-gradient-to-r from-green-500 to-emerald-500"
                    >
                      <Save className="h-4 w-4 mr-2" />
                      Save
                    </Button>
                    <Button variant="outline" onClick={handleCancelEdit}>
                      <X className="h-4 w-4 mr-2" />
                      Cancel
                    </Button>
                  </div>
                ) : (
                  <div className="flex items-center gap-3 mt-2">
                    <p className="text-lg font-semibold">{displayName}</p>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setIsEditing(true)}
                    >
                      Edit
                    </Button>
                  </div>
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex items-center gap-3 p-3 bg-blue-50 rounded-lg border border-blue-200">
                  <Mail className="h-5 w-5 text-blue-600" />
                  <div>
                    <p className="text-xs text-gray-600">Email</p>
                    <p className="font-medium text-gray-900">{userEmail}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3 p-3 bg-green-50 rounded-lg border border-green-200">
                  <Calendar className="h-5 w-5 text-green-600" />
                  <div>
                    <p className="text-xs text-gray-600">Member Since</p>
                    <p className="font-medium text-gray-900">{joinDate}</p>
                  </div>
                </div>
              </div>

              <div>
                <Badge className="bg-gradient-to-r from-green-500 to-emerald-500">
                  Active Account
                </Badge>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Security Settings Card */}
      <Card className="border-2 border-blue-200 shadow-lg">
        <CardHeader className="bg-gradient-to-r from-blue-100 to-cyan-100">
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5 text-blue-600" />
            Security Settings
          </CardTitle>
          <CardDescription>Manage your account security</CardDescription>
        </CardHeader>
        <CardContent className="pt-6 space-y-4">
          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg border">
            <div>
              <p className="font-semibold text-gray-900">Password</p>
              <p className="text-sm text-gray-600">Last changed 30 days ago</p>
            </div>
            <Button
              variant="outline"
              onClick={() => navigate('/reset-password')}
            >
              Change Password
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Data Management Card */}
      <Card className="border-2 border-green-200 shadow-lg">
        <CardHeader className="bg-gradient-to-r from-green-100 to-emerald-100">
          <CardTitle className="flex items-center gap-2">
            <Database className="h-5 w-5 text-green-600" />
            Data Management
          </CardTitle>
          <CardDescription>Manage your stored data and preferences</CardDescription>
        </CardHeader>
        <CardContent className="pt-6 space-y-4">
          <div>
            <div className="flex items-center justify-between mb-2">
              <p className="font-semibold text-gray-900">Storage Usage</p>
              <p className="text-sm text-gray-600">{calculateStorageUsage().toFixed(1)}% used</p>
            </div>
            <Progress value={calculateStorageUsage()} className="h-2" />
            <p className="text-xs text-gray-500 mt-2">
              {JSON.parse(localStorage.getItem('receipts') || '[]').length} receipts, {' '}
              {JSON.parse(localStorage.getItem('products') || '[]').length} products, {' '}
              {JSON.parse(localStorage.getItem('bundles') || '[]').length} bundles
            </p>
          </div>

          <Separator />

          <div className="flex items-center justify-between">
            <div>
              <p className="font-semibold text-gray-900">Export All Data</p>
              <p className="text-sm text-gray-600">Download all your data as JSON</p>
            </div>
            <Button
              variant="outline"
              onClick={handleExportData}
              className="bg-gradient-to-r from-blue-500 to-cyan-500 text-white hover:from-blue-600 hover:to-cyan-600"
            >
              <Download className="h-4 w-4 mr-2" />
              Export
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}