import { Outlet, useNavigate, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { 
  LayoutDashboard, 
  Upload, 
  Sparkles, 
  BarChart3, 
  Download,
  LogOut,
  Menu,
  X,
  Package,
  User
} from 'lucide-react';
import { signOut } from '@/lib/supabase';
import { toast } from 'sonner';
import { useState, useEffect } from 'react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

export default function Dashboard() {
  const navigate = useNavigate();
  const location = useLocation();
  
  // Load sidebar state from localStorage
  const [sidebarOpen, setSidebarOpen] = useState(() => {
    const saved = localStorage.getItem('sidebarOpen');
    return saved !== null ? JSON.parse(saved) : true;
  });

  // Get user email and display name from localStorage
  const [userEmail, setUserEmail] = useState('');
  const [displayName, setDisplayName] = useState('');

  useEffect(() => {
    const email = localStorage.getItem('userEmail') || 'user@example.com';
    const name = localStorage.getItem('displayName') || email.split('@')[0];
    setUserEmail(email);
    setDisplayName(name);
  }, [location]); // Re-load when location changes (after profile update)

  // Save sidebar state to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem('sidebarOpen', JSON.stringify(sidebarOpen));
  }, [sidebarOpen]);

  const handleLogout = async () => {
    try {
      await signOut();
      toast.success('Logged out successfully');
      navigate('/');
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'An unknown error occurred';
      toast.error('Logout failed: ' + errorMessage);
    }
  };

  const navItems = [
    { icon: LayoutDashboard, label: 'Home', path: '/dashboard', color: 'from-blue-500 to-cyan-500' },
    { icon: Upload, label: 'Upload Data', path: '/dashboard/upload', color: 'from-green-500 to-emerald-500' },
    { icon: Sparkles, label: 'Generate Bundles', path: '/dashboard/generate', color: 'from-purple-500 to-pink-500' },
    { icon: BarChart3, label: 'Analytics', path: '/dashboard/analytics', color: 'from-orange-500 to-red-500' },
    { icon: Download, label: 'Export', path: '/dashboard/export', color: 'from-indigo-500 to-blue-500' },
  ];

  const isActive = (path: string) => location.pathname === path;

  // Get user initials for avatar
  const getUserInitials = (name: string) => {
    return name.substring(0, 2).toUpperCase();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 flex">
      {/* Sidebar Navigation */}
      <aside className={`${sidebarOpen ? 'w-64' : 'w-20'} bg-white border-r-2 border-purple-200 shadow-lg transition-all duration-300 flex flex-col`}>
        {/* Logo Header */}
        <div className="h-16 border-b-2 border-purple-200 flex items-center justify-between px-4 bg-gradient-to-r from-purple-600 to-pink-600">
          {sidebarOpen ? (
            <>
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-lg bg-white flex items-center justify-center">
                  <Package className="h-6 w-6 text-purple-600" />
                </div>
                <h1 className="text-lg font-bold text-white">
                  Bundle
                </h1>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setSidebarOpen(false)}
                className="text-white hover:bg-purple-700"
              >
                <X className="h-5 w-5" />
              </Button>
            </>
          ) : (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setSidebarOpen(true)}
              className="mx-auto text-white hover:bg-purple-700"
            >
              <Menu className="h-5 w-5" />
            </Button>
          )}
        </div>

        {/* Navigation Items */}
        <nav className="flex-1 py-4 px-2 space-y-2">
          {navItems.map((item) => {
            const active = isActive(item.path);
            return (
              <Button
                key={item.path}
                variant={active ? "default" : "ghost"}
                className={`w-full ${sidebarOpen ? 'justify-start' : 'justify-center'} transition-all duration-200 ${
                  active 
                    ? `bg-gradient-to-r ${item.color} text-white shadow-md` 
                    : 'hover:bg-purple-100'
                }`}
                onClick={() => navigate(item.path)}
              >
                <item.icon className={`h-5 w-5 ${sidebarOpen ? 'mr-3' : ''}`} />
                {sidebarOpen && <span>{item.label}</span>}
              </Button>
            );
          })}
        </nav>

        {/* User Profile Section */}
        <div className="p-2 border-t-2 border-purple-200 bg-gradient-to-br from-purple-50 to-pink-50">
          {sidebarOpen ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="ghost"
                  className="w-full justify-start hover:bg-purple-100 p-3"
                >
                  <Avatar className="h-9 w-9 mr-3 bg-gradient-to-br from-purple-600 to-pink-600">
                    <AvatarFallback className="bg-transparent text-white font-semibold">
                      {getUserInitials(displayName)}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex flex-col items-start text-left flex-1 min-w-0">
                    <span className="text-sm font-semibold text-gray-900 truncate w-full">
                      {displayName}
                    </span>
                    <span className="text-xs text-gray-500 truncate w-full">
                      {userEmail}
                    </span>
                  </div>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuLabel>My Account</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => navigate('/dashboard/profile')}>
                  <User className="mr-2 h-4 w-4" />
                  <span>Profile</span>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleLogout} className="text-red-600">
                  <LogOut className="mr-2 h-4 w-4" />
                  <span>Logout</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="ghost"
                  className="w-full justify-center hover:bg-purple-100 p-2"
                >
                  <Avatar className="h-9 w-9 bg-gradient-to-br from-purple-600 to-pink-600">
                    <AvatarFallback className="bg-transparent text-white font-semibold">
                      {getUserInitials(displayName)}
                    </AvatarFallback>
                  </Avatar>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuLabel>
                  <div className="flex flex-col">
                    <span>{displayName}</span>
                    <span className="text-xs font-normal text-gray-500">{userEmail}</span>
                  </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => navigate('/dashboard/profile')}>
                  <User className="mr-2 h-4 w-4" />
                  <span>Profile</span>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleLogout} className="text-red-600">
                  <LogOut className="mr-2 h-4 w-4" />
                  <span>Logout</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          )}
        </div>
      </aside>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col">
        {/* Top Header */}
        <header className="h-16 bg-white border-b-2 border-purple-200 shadow-sm flex items-center justify-between px-6">
          <h2 className="text-2xl font-bold bg-gradient-to-r from-purple-600 via-pink-600 to-orange-500 bg-clip-text text-transparent">
            Bundle Recommender
          </h2>
          <div className="flex items-center gap-4">
            <div className="text-sm text-gray-600">
              Welcome back, {displayName}!
            </div>
          </div>
        </header>

        {/* Main Content */}
        <main className="flex-1 overflow-auto p-6">
          <div className="max-w-7xl mx-auto">
            <Outlet />
          </div>
        </main>
      </div>
    </div>
  );
}