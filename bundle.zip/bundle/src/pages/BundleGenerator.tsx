import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { BundleItem, CategoryConfig, SalesReport } from '@/lib/storage';
import { getCurrentUser } from '@/lib/supabase';
import { Package, Sparkles, TrendingUp, AlertCircle } from 'lucide-react';
import { toast } from 'sonner';
import DataCatalog from '@/components/DataCatalog';

interface GeneratedBundle {
  items: BundleItem[];
  totalPrice: number;
  coPurchasePercentage: number;
  supportCount: number;
}

export default function BundleGenerator() {
  const [user, setUser] = useState<{ id: string; email: string } | null>(null);
  const [allReports, setAllReports] = useState<SalesReport[]>([]);
  const [selectedReports, setSelectedReports] = useState<string[]>([]);
  const [categoryConfigs, setCategoryConfigs] = useState<CategoryConfig[]>([]);
  const [generatedBundles, setGeneratedBundles] = useState<GeneratedBundle[]>([]);

  useEffect(() => {
    const loadUser = async () => {
      const currentUser = await getCurrentUser();
      if (currentUser) {
        setUser(currentUser);
        loadReports(currentUser.id);
      }
    };
    loadUser();
  }, []);

  const loadReports = (userId: string) => {
    const reportsStr = localStorage.getItem('salesReports');
    const reports: SalesReport[] = reportsStr ? JSON.parse(reportsStr) : [];
    setAllReports(reports.filter(r => r.userId === userId));
  };

  // Get categories from selected reports only
  const getSelectedCategories = (): string[] => {
    const reports = allReports.filter(r => selectedReports.includes(r.id));
    const categories = new Set<string>();
    reports.forEach(report => {
      report.data.forEach(item => {
        if (item.category) {
          categories.add(item.category);
        }
      });
    });
    return Array.from(categories).sort();
  };

  useEffect(() => {
    const categories = getSelectedCategories();
    if (categories.length > 0 && categoryConfigs.length === 0) {
      setCategoryConfigs(categories.map(cat => ({
        category: cat,
        productCount: 1,
      })));
    }
  }, [selectedReports]);

  const updateCategoryConfig = (index: number, value: number) => {
    const newConfigs = [...categoryConfigs];
    newConfigs[index] = { ...newConfigs[index], productCount: value };
    setCategoryConfigs(newConfigs);
  };

  const generateBundles = () => {
    if (selectedReports.length === 0) {
      toast.error('Please select at least one dataset from the catalog');
      return;
    }

    const reports = allReports.filter(r => selectedReports.includes(r.id));

    // Group products by receipt
    const receiptMap = new Map<string, Set<string>>();
    const productInfo = new Map<string, { category: string; price: number }>();
    
    reports.forEach(report => {
      report.data.forEach(item => {
        if (!receiptMap.has(item.receiptId)) {
          receiptMap.set(item.receiptId, new Set());
        }
        receiptMap.get(item.receiptId)!.add(item.product);
        
        if (!productInfo.has(item.product)) {
          productInfo.set(item.product, {
            category: item.category,
            price: item.price,
          });
        }
      });
    });

    const totalReceipts = receiptMap.size;
    
    // Get products by category
    const categoryProducts = new Map<string, string[]>();
    productInfo.forEach((info, product) => {
      if (!categoryProducts.has(info.category)) {
        categoryProducts.set(info.category, []);
      }
      categoryProducts.get(info.category)!.push(product);
    });

    // Generate all possible product combinations based on category configs
    const generateCombinations = (configs: CategoryConfig[]): string[][] => {
      const results: string[][] = [];
      
      const backtrack = (index: number, current: string[]) => {
        if (index === configs.length) {
          if (current.length > 0) {
            results.push([...current]);
          }
          return;
        }
        
        const config = configs[index];
        const products = categoryProducts.get(config.category) || [];
        
        if (config.productCount === 0) {
          backtrack(index + 1, current);
          return;
        }
        
        // Generate combinations of productCount from this category
        const combine = (start: number, selected: string[]) => {
          if (selected.length === config.productCount) {
            backtrack(index + 1, [...current, ...selected]);
            return;
          }
          
          for (let i = start; i < products.length; i++) {
            combine(i + 1, [...selected, products[i]]);
          }
        };
        
        combine(0, []);
      };
      
      backtrack(0, []);
      return results;
    };

    const combinations = generateCombinations(categoryConfigs);
    
    // Calculate co-purchase percentage for each combination
    const bundleStats: GeneratedBundle[] = [];
    
    combinations.forEach(combo => {
      let supportCount = 0;
      
      receiptMap.forEach(receiptProducts => {
        const hasAll = combo.every(product => receiptProducts.has(product));
        if (hasAll) {
          supportCount++;
        }
      });
      
      const percentage = (supportCount / totalReceipts) * 100;
      
      if (supportCount > 0) {
        const items: BundleItem[] = combo.map(product => {
          const info = productInfo.get(product)!;
          return {
            product,
            category: info.category,
            price: info.price,
          };
        });
        
        const totalPrice = items.reduce((sum, item) => sum + item.price, 0);
        
        bundleStats.push({
          items,
          totalPrice,
          coPurchasePercentage: Math.round(percentage * 100) / 100,
          supportCount,
        });
      }
    });

    // Sort by co-purchase percentage descending
    bundleStats.sort((a, b) => b.coPurchasePercentage - a.coPurchasePercentage);
    
    setGeneratedBundles(bundleStats);
    
    if (bundleStats.length === 0) {
      toast.error('No bundles found with the current configuration. Try adjusting the product counts.');
    } else {
      toast.success(`Generated ${bundleStats.length} bundle(s) from ${selectedReports.length} dataset(s)!`);
    }
  };

  const saveBundle = (bundleIndex: number) => {
    if (!user) return;

    const bundle = generatedBundles[bundleIndex];
    if (!bundle) return;

    const name = `Bundle ${bundleIndex + 1} (${bundle.coPurchasePercentage}% co-purchase)`;

    const newBundle = {
      id: Date.now().toString() + bundleIndex,
      userId: user.id,
      bundleName: name,
      items: bundle.items,
      totalPrice: bundle.totalPrice,
      coPurchasePercentage: bundle.coPurchasePercentage,
      createdDate: new Date().toISOString(),
    };

    // Save to localStorage
    const bundlesStr = localStorage.getItem('bundles');
    const bundles = bundlesStr ? JSON.parse(bundlesStr) : [];
    bundles.push(newBundle);
    localStorage.setItem('bundles', JSON.stringify(bundles));

    toast.success(`Bundle "${name}" saved successfully!`);
  };

  const saveAllBundles = () => {
    if (!user || generatedBundles.length === 0) return;

    const bundlesStr = localStorage.getItem('bundles');
    const bundles = bundlesStr ? JSON.parse(bundlesStr) : [];

    generatedBundles.forEach((bundle, index) => {
      const name = `Bundle ${index + 1} (${bundle.coPurchasePercentage}% co-purchase)`;
      const newBundle = {
        id: Date.now().toString() + index,
        userId: user.id,
        bundleName: name,
        items: bundle.items,
        totalPrice: bundle.totalPrice,
        coPurchasePercentage: bundle.coPurchasePercentage,
        createdDate: new Date().toISOString(),
      };
      bundles.push(newBundle);
    });

    localStorage.setItem('bundles', JSON.stringify(bundles));
    toast.success(`All ${generatedBundles.length} bundles saved successfully!`);
    setGeneratedBundles([]);
  };

  const categories = getSelectedCategories();

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
          Generate Bundles
        </h2>
        <p className="text-gray-600 mt-2">Analyze receipt data to find products frequently bought together</p>
      </div>

      {/* Data Catalog at the top */}
      <DataCatalog 
        reports={allReports}
        selectedReports={selectedReports}
        onSelectionChange={setSelectedReports}
      />

      {selectedReports.length === 0 && (
        <Card className="border-2 border-yellow-300 bg-yellow-50">
          <CardContent className="pt-6">
            <div className="flex items-start gap-3">
              <AlertCircle className="h-5 w-5 text-yellow-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold text-yellow-900">No datasets selected</p>
                <p className="text-sm text-yellow-700 mt-1">
                  Please select one or more datasets from the catalog above to generate bundles.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {selectedReports.length > 0 && (
        <Card className="border-2 border-purple-200 bg-gradient-to-br from-purple-50 to-pink-50">
          <CardHeader className="bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-t-lg">
            <CardTitle>Category Configuration</CardTitle>
            <CardDescription className="text-purple-100">
              Set how many products to include from each category (0 to exclude category)
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4 pt-6">
            {categories.length === 0 ? (
              <div className="p-4 bg-yellow-50 border-2 border-yellow-200 rounded-lg">
                <p className="text-sm text-yellow-800">
                  No categories found in selected datasets. Please check your data.
                </p>
              </div>
            ) : (
              <>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {categoryConfigs.map((config, index) => (
                    <div key={config.category} className="p-4 border-2 border-purple-200 rounded-lg bg-white shadow-sm hover:shadow-md transition-shadow">
                      <div className="flex items-center justify-between">
                        <h4 className="font-semibold text-lg text-purple-900">{config.category}</h4>
                        <div className="flex items-center gap-2">
                          <Label className="text-sm text-gray-600">Products:</Label>
                          <Input
                            type="number"
                            min="0"
                            max="10"
                            value={config.productCount}
                            onChange={(e) => updateCategoryConfig(index, parseInt(e.target.value) || 0)}
                            className="w-20 border-purple-300 focus:border-purple-500"
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                <Button 
                  onClick={generateBundles} 
                  className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white shadow-lg" 
                  size="lg"
                >
                  <Sparkles className="mr-2 h-5 w-5" />
                  Analyze {selectedReports.length} Dataset(s) & Generate Bundles
                </Button>
              </>
            )}
          </CardContent>
        </Card>
      )}

      {generatedBundles.length > 0 && (
        <Card className="border-2 border-green-200 bg-gradient-to-br from-green-50 to-emerald-50">
          <CardHeader className="bg-gradient-to-r from-green-600 to-emerald-600 text-white rounded-t-lg">
            <div className="flex justify-between items-center">
              <div>
                <CardTitle>Generated Bundles</CardTitle>
                <CardDescription className="text-green-100">
                  Bundles ranked by actual co-purchase rate from receipts
                </CardDescription>
              </div>
              <Button 
                onClick={saveAllBundles} 
                variant="secondary"
                className="bg-white text-green-700 hover:bg-green-50"
              >
                <Package className="mr-2 h-4 w-4" />
                Save All Bundles
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-6 pt-6">
            {generatedBundles.map((bundle, bundleIndex) => (
              <div key={bundleIndex} className="border-2 border-green-300 rounded-lg p-5 space-y-4 bg-white shadow-md hover:shadow-lg transition-shadow">
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="text-xl font-bold text-green-900">
                      Bundle {bundleIndex + 1}
                    </h3>
                    <div className="flex items-center gap-3 mt-3 flex-wrap">
                      <Badge className="bg-blue-100 text-blue-700 hover:bg-blue-200">
                        <TrendingUp className="h-3 w-3 mr-1" />
                        {bundle.supportCount} receipts
                      </Badge>
                      <Badge className="bg-purple-100 text-purple-700 hover:bg-purple-200">
                        {bundle.coPurchasePercentage}% co-purchase rate
                      </Badge>
                      <Badge className="bg-green-100 text-green-700 hover:bg-green-200">
                        ${bundle.totalPrice.toFixed(2)} total
                      </Badge>
                    </div>
                  </div>
                  <Button 
                    size="sm" 
                    onClick={() => saveBundle(bundleIndex)}
                    className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700"
                  >
                    <Package className="mr-2 h-4 w-4" />
                    Save Bundle
                  </Button>
                </div>

                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="font-bold">Product</TableHead>
                      <TableHead className="font-bold">Category</TableHead>
                      <TableHead className="font-bold">Unit Price</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {bundle.items.map((item, itemIndex) => (
                      <TableRow key={itemIndex}>
                        <TableCell className="font-medium">{item.product}</TableCell>
                        <TableCell>
                          <Badge variant="outline">{item.category}</Badge>
                        </TableCell>
                        <TableCell className="font-semibold text-green-600">
                          ${item.price.toFixed(2)}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            ))}
          </CardContent>
        </Card>
      )}
    </div>
  );
}