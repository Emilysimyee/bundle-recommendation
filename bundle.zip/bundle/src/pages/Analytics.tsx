import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { SalesReport } from '@/lib/storage';
import { getCurrentUser } from '@/lib/supabase';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from 'recharts';
import { TrendingUp } from 'lucide-react';

const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#14b8a6', '#f97316'];

export default function Analytics() {
  const [user, setUser] = useState<{ id: string; email: string } | null>(null);
  const [reports, setReports] = useState<SalesReport[]>([]);

  useEffect(() => {
    const loadUser = async () => {
      const currentUser = await getCurrentUser();
      if (currentUser) {
        setUser(currentUser);
        loadReports(currentUser.id);
      }
    };
    loadUser();
  }, []);

  const loadReports = (userId: string) => {
    const reportsStr = localStorage.getItem('salesReports');
    const allReports: SalesReport[] = reportsStr ? JSON.parse(reportsStr) : [];
    setReports(allReports.filter(r => r.userId === userId));
  };

  // Aggregate data by product
  const productData = new Map<string, { quantity: number; revenue: number }>();
  reports.forEach(report => {
    report.data.forEach(item => {
      const existing = productData.get(item.product) || { quantity: 0, revenue: 0 };
      productData.set(item.product, {
        quantity: existing.quantity + item.quantity,
        revenue: existing.revenue + (item.price * item.quantity),
      });
    });
  });

  const chartData = Array.from(productData.entries())
    .map(([product, data]) => ({
      product: product.length > 15 ? product.substring(0, 15) + '...' : product,
      quantity: data.quantity,
      revenue: data.revenue,
    }))
    .sort((a, b) => b.quantity - a.quantity)
    .slice(0, 10);

  // Category data
  const categoryData = new Map<string, { quantity: number; revenue: number }>();
  reports.forEach(report => {
    report.data.forEach(item => {
      const existing = categoryData.get(item.category) || { quantity: 0, revenue: 0 };
      categoryData.set(item.category, {
        quantity: existing.quantity + item.quantity,
        revenue: existing.revenue + (item.price * item.quantity),
      });
    });
  });

  const categoryChartData = Array.from(categoryData.entries())
    .map(([category, data]) => ({
      name: category,
      value: data.revenue,
      quantity: data.quantity,
    }))
    .sort((a, b) => b.value - a.value);

  // Time series data
  const dateData = new Map<string, { quantity: number; revenue: number }>();
  reports.forEach(report => {
    report.data.forEach(item => {
      const existing = dateData.get(item.date) || { quantity: 0, revenue: 0 };
      dateData.set(item.date, {
        quantity: existing.quantity + item.quantity,
        revenue: existing.revenue + (item.price * item.quantity),
      });
    });
  });

  const timeSeriesData = Array.from(dateData.entries())
    .map(([date, data]) => ({
      date,
      quantity: data.quantity,
      revenue: data.revenue,
    }))
    .sort((a, b) => a.date.localeCompare(b.date));

  const totalRevenue = Array.from(productData.values()).reduce((sum, d) => sum + d.revenue, 0);
  const totalQuantity = Array.from(productData.values()).reduce((sum, d) => sum + d.quantity, 0);

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold text-gray-900">Sales Analytics</h2>
        <p className="text-gray-600 mt-2">Visualize your product performance and trends</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
            <TrendingUp className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${totalRevenue.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}</div>
            <p className="text-xs text-gray-500 mt-1">From all sales data</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Total Units Sold</CardTitle>
            <TrendingUp className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalQuantity.toLocaleString()}</div>
            <p className="text-xs text-gray-500 mt-1">Across all products</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Categories</CardTitle>
            <TrendingUp className="h-4 w-4 text-purple-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{categoryData.size}</div>
            <p className="text-xs text-gray-500 mt-1">Product categories</p>
          </CardContent>
        </Card>
      </div>

      {chartData.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center text-gray-500">
            <p>No sales data available</p>
            <p className="text-sm">Upload sales reports to see analytics</p>
          </CardContent>
        </Card>
      ) : (
        <>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Revenue by Category</CardTitle>
                <CardDescription>Distribution of revenue across categories</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={categoryChartData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {categoryChartData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value: number) => `$${value.toFixed(2)}`} />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Category Performance</CardTitle>
                <CardDescription>Revenue by category</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={categoryChartData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip formatter={(value: number) => `$${value.toFixed(2)}`} />
                    <Legend />
                    <Bar dataKey="value" fill="#10b981" name="Revenue ($)" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Top Products by Quantity Sold</CardTitle>
              <CardDescription>Top 10 best-selling products</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <BarChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="product" angle={-45} textAnchor="end" height={100} />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="quantity" fill="#3b82f6" name="Quantity Sold" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Revenue by Product</CardTitle>
              <CardDescription>Top 10 products by revenue generated</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <BarChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="product" angle={-45} textAnchor="end" height={100} />
                  <YAxis />
                  <Tooltip formatter={(value: number) => `$${value.toFixed(2)}`} />
                  <Legend />
                  <Bar dataKey="revenue" fill="#10b981" name="Revenue ($)" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {timeSeriesData.length > 1 && (
            <Card>
              <CardHeader>
                <CardTitle>Sales Trends Over Time</CardTitle>
                <CardDescription>Daily sales performance</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={400}>
                  <LineChart data={timeSeriesData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip formatter={(value: number, name: string) => 
                      name === 'revenue' ? `$${value.toFixed(2)}` : value
                    } />
                    <Legend />
                    <Line type="monotone" dataKey="quantity" stroke="#3b82f6" name="Quantity" />
                    <Line type="monotone" dataKey="revenue" stroke="#10b981" name="Revenue ($)" />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          )}
        </>
      )}
    </div>
  );
}