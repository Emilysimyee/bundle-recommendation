import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { Bundle } from '@/lib/storage';
import { getCurrentUser } from '@/lib/supabase';
import { Download, Trash2, Package, AlertTriangle } from 'lucide-react';
import { toast } from 'sonner';

export default function ExportBundles() {
  const [user, setUser] = useState<{ id: string; email: string } | null>(null);
  const [loading, setLoading] = useState(true);
  const [bundles, setBundles] = useState<Bundle[]>([]);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [bundleToDelete, setBundleToDelete] = useState<{ id: string; name: string } | null>(null);

  useEffect(() => {
    const loadUser = async () => {
      const currentUser = await getCurrentUser();
      setUser(currentUser);
      if (currentUser) {
        loadBundles(currentUser.id);
      }
      setLoading(false);
    };
    loadUser();
  }, []);

  const loadBundles = (userId: string) => {
    const bundlesStr = localStorage.getItem('bundles');
    const allBundles: Bundle[] = bundlesStr ? JSON.parse(bundlesStr) : [];
    setBundles(allBundles.filter(b => b.userId === userId));
  };

  const handleExport = (bundleId: string) => {
    const bundle = bundles.find(b => b.id === bundleId);
    if (!bundle) return;

    // Create CSV content
    let csvContent = 'Bundle Name,Product,Category,Unit Price,Bundle Total Price,Co-Purchase %\n';
    bundle.items.forEach((item, index) => {
      csvContent += `"${bundle.bundleName}","${item.product}","${item.category}",${item.price.toFixed(2)},${index === 0 ? bundle.totalPrice.toFixed(2) : ''},${index === 0 ? bundle.coPurchasePercentage : ''}\n`;
    });

    // Create and download file
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${bundle.bundleName.replace(/[^a-z0-9]/gi, '_')}_${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);

    toast.success('Bundle exported successfully!');
  };

  const handleExportAll = () => {
    if (bundles.length === 0) {
      toast.error('No bundles to export');
      return;
    }

    // Create CSV content for all bundles
    let csvContent = 'Bundle Name,Product,Category,Unit Price,Bundle Total Price,Co-Purchase %,Created Date\n';
    bundles.forEach(bundle => {
      bundle.items.forEach((item, index) => {
        csvContent += `"${bundle.bundleName}","${item.product}","${item.category}",${item.price.toFixed(2)},${index === 0 ? bundle.totalPrice.toFixed(2) : ''},${index === 0 ? bundle.coPurchasePercentage : ''},${index === 0 ? new Date(bundle.createdDate).toLocaleDateString() : ''}\n`;
      });
    });

    // Create and download file
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `all_bundles_${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);

    toast.success('All bundles exported successfully!');
  };

  const handleDeleteClick = (bundleId: string, bundleName: string) => {
    setBundleToDelete({ id: bundleId, name: bundleName });
    setShowDeleteDialog(true);
  };

  const confirmDelete = () => {
    if (!bundleToDelete || !user) return;

    const bundlesStr = localStorage.getItem('bundles');
    const allBundles: Bundle[] = bundlesStr ? JSON.parse(bundlesStr) : [];
    const filtered = allBundles.filter(b => b.id !== bundleToDelete.id);
    localStorage.setItem('bundles', JSON.stringify(filtered));

    loadBundles(user.id);
    toast.success('Bundle deleted successfully');
    setShowDeleteDialog(false);
    setBundleToDelete(null);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold text-gray-900">Export Bundles</h2>
          <p className="text-gray-600 mt-2">Download and manage your saved bundle recommendations</p>
        </div>
        {bundles.length > 0 && (
          <Button onClick={handleExportAll}>
            <Download className="mr-2 h-4 w-4" />
            Export All Bundles
          </Button>
        )}
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Saved Bundles</CardTitle>
          <CardDescription>Your bundle recommendations ready for export</CardDescription>
        </CardHeader>
        <CardContent>
          {bundles.length === 0 ? (
            <div className="text-center py-12 text-gray-500">
              <Package className="h-12 w-12 mx-auto mb-4 text-gray-400" />
              <p>No bundles saved yet</p>
              <p className="text-sm">Generate and save bundles to export them</p>
            </div>
          ) : (
            <div className="space-y-6">
              {bundles.map((bundle) => (
                <div key={bundle.id} className="border rounded-lg p-4 space-y-4">
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="text-lg font-semibold">{bundle.bundleName}</h3>
                      <div className="flex gap-2 mt-2">
                        <Badge variant="secondary">
                          Co-Purchase: {bundle.coPurchasePercentage}%
                        </Badge>
                        <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                          Bundle Price: ${bundle.totalPrice.toFixed(2)}
                        </Badge>
                      </div>
                      <p className="text-sm text-gray-500 mt-1">
                        Created: {new Date(bundle.createdDate).toLocaleDateString()}
                      </p>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleExport(bundle.id)}
                      >
                        <Download className="h-4 w-4 mr-2" />
                        Export
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleDeleteClick(bundle.id, bundle.bundleName)}
                        className="text-red-600 hover:text-red-700 hover:bg-red-50"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>

                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Product</TableHead>
                        <TableHead>Category</TableHead>
                        <TableHead>Unit Price</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {bundle.items.map((item, idx) => (
                        <TableRow key={idx}>
                          <TableCell className="font-medium">{item.product}</TableCell>
                          <TableCell>{item.category}</TableCell>
                          <TableCell>${item.price.toFixed(2)}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2 text-red-600">
              <AlertTriangle className="h-5 w-5" />
              Delete Bundle
            </AlertDialogTitle>
            <AlertDialogDescription className="space-y-2">
              <p>Are you sure you want to delete this bundle?</p>
              {bundleToDelete && (
                <p className="font-semibold text-gray-900">"{bundleToDelete.name}"</p>
              )}
              <p className="text-red-600">This action cannot be undone.</p>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setBundleToDelete(null)}>
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDelete}
              className="bg-red-600 hover:bg-red-700 focus:ring-red-600"
            >
              <Trash2 className="mr-2 h-4 w-4" />
              Delete Bundle
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}