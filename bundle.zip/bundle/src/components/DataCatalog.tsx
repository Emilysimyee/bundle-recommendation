import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { ScrollArea } from '@/components/ui/scroll-area';
import { SalesReport } from '@/lib/storage';
import { FileSpreadsheet, Download, Calendar, Package, Layers, CheckCircle2 } from 'lucide-react';
import { toast } from 'sonner';

interface DataCatalogProps {
  reports: SalesReport[];
  selectedReports: string[];
  onSelectionChange: (reportIds: string[]) => void;
}

export default function DataCatalog({ reports, selectedReports, onSelectionChange }: DataCatalogProps) {
  const toggleReport = (reportId: string) => {
    if (selectedReports.includes(reportId)) {
      onSelectionChange(selectedReports.filter(id => id !== reportId));
    } else {
      onSelectionChange([...selectedReports, reportId]);
    }
  };

  const selectAll = () => {
    onSelectionChange(reports.map(r => r.id));
  };

  const deselectAll = () => {
    onSelectionChange([]);
  };

  const downloadReport = (report: SalesReport) => {
    // Convert data back to CSV
    const headers = ['Receipt ID', 'Product', 'Category', 'Quantity', 'Price', 'Date'];
    const csvContent = [
      headers.join(','),
      ...report.data.map(item => 
        [item.receiptId, item.product, item.category, item.quantity, item.price, item.date].join(',')
      )
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = report.fileName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    toast.success(`Downloaded ${report.fileName}`);
  };

  const downloadAllSelected = () => {
    const selected = reports.filter(r => selectedReports.includes(r.id));
    if (selected.length === 0) {
      toast.error('Please select at least one report to download');
      return;
    }

    selected.forEach(report => downloadReport(report));
    toast.success(`Downloaded ${selected.length} report(s)`);
  };

  return (
    <Card className="h-full border-2 border-purple-200 bg-gradient-to-br from-purple-50 to-pink-50">
      <CardHeader className="pb-3 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-t-lg">
        <CardTitle className="flex items-center gap-2 text-lg">
          <Layers className="h-5 w-5" />
          Data Catalog
        </CardTitle>
        <CardDescription className="text-purple-100">
          Select datasets for analysis
        </CardDescription>
      </CardHeader>
      <CardContent className="pt-4 space-y-3">
        {reports.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            <FileSpreadsheet className="h-12 w-12 mx-auto mb-3 text-gray-400" />
            <p className="text-sm">No data uploaded yet</p>
          </div>
        ) : (
          <>
            <div className="flex gap-2">
              <Button 
                size="sm" 
                variant="outline" 
                onClick={selectAll}
                className="flex-1 border-purple-300 hover:bg-purple-100"
              >
                Select All
              </Button>
              <Button 
                size="sm" 
                variant="outline" 
                onClick={deselectAll}
                className="flex-1 border-purple-300 hover:bg-purple-100"
              >
                Clear
              </Button>
            </div>

            {selectedReports.length > 0 && (
              <Button 
                size="sm" 
                onClick={downloadAllSelected}
                className="w-full bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700"
              >
                <Download className="h-4 w-4 mr-2" />
                Download Selected ({selectedReports.length})
              </Button>
            )}

            <ScrollArea className="h-[calc(100vh-320px)]">
              <div className="space-y-3 pr-4">
                {reports.map((report) => {
                  const isSelected = selectedReports.includes(report.id);
                  const uniqueReceipts = new Set(report.data.map(d => d.receiptId)).size;
                  const uniqueProducts = new Set(report.data.map(d => d.product)).size;
                  const uniqueCategories = new Set(report.data.map(d => d.category)).size;

                  return (
                    <Card 
                      key={report.id} 
                      className={`cursor-pointer transition-all duration-200 ${
                        isSelected 
                          ? 'border-2 border-purple-500 bg-purple-50 shadow-md' 
                          : 'border border-gray-200 hover:border-purple-300 hover:shadow-sm'
                      }`}
                      onClick={() => toggleReport(report.id)}
                    >
                      <CardContent className="p-3">
                        <div className="flex items-start gap-3">
                          <Checkbox 
                            checked={isSelected}
                            onCheckedChange={() => toggleReport(report.id)}
                            className="mt-1"
                          />
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 mb-2">
                              <FileSpreadsheet className="h-4 w-4 text-purple-600 flex-shrink-0" />
                              <h4 className="font-semibold text-sm truncate">{report.fileName}</h4>
                              {isSelected && (
                                <CheckCircle2 className="h-4 w-4 text-purple-600 flex-shrink-0" />
                              )}
                            </div>
                            
                            <div className="space-y-1.5 text-xs text-gray-600">
                              <div className="flex items-center gap-1.5">
                                <Calendar className="h-3 w-3 text-blue-500" />
                                <span>{new Date(report.uploadDate).toLocaleDateString()}</span>
                              </div>
                              
                              <div className="flex flex-wrap gap-1.5">
                                <Badge variant="secondary" className="text-xs bg-blue-100 text-blue-700">
                                  <Package className="h-3 w-3 mr-1" />
                                  {uniqueReceipts} receipts
                                </Badge>
                                <Badge variant="secondary" className="text-xs bg-green-100 text-green-700">
                                  {uniqueProducts} products
                                </Badge>
                                <Badge variant="secondary" className="text-xs bg-orange-100 text-orange-700">
                                  {uniqueCategories} categories
                                </Badge>
                              </div>
                            </div>
                          </div>
                          
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={(e) => {
                              e.stopPropagation();
                              downloadReport(report);
                            }}
                            className="flex-shrink-0 h-8 w-8 p-0 hover:bg-green-100"
                          >
                            <Download className="h-4 w-4 text-green-600" />
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </ScrollArea>
          </>
        )}
      </CardContent>
    </Card>
  );
}