# Bundle Recommendation Website - MVP Todo List

## Overview
A web application for managing product bundles with user authentication, sales data upload, bundle generation, and analytics dashboard.

## Tech Stack
- Frontend: React + TypeScript + Shadcn-UI + Tailwind CSS
- Backend: Supabase (Authentication + Database)
- Charts: Recharts (already available in shadcn-ui)

## Database Schema (Supabase)
1. Users table (handled by Supabase Auth)
2. sales_reports table: id, user_id, file_name, upload_date, data (jsonb)
3. bundles table: id, user_id, bundle_name, items (jsonb), created_date
4. bundle_items table: id, bundle_id, product_name, quantity

## Files to Create/Modify (Max 8 files)

### 1. src/lib/supabase.ts
- Initialize Supabase client
- Export supabase instance

### 2. src/pages/Index.tsx
- Landing page with login/register
- Auth forms (login/register)
- Redirect to dashboard if authenticated

### 3. src/pages/Dashboard.tsx
- Main dashboard layout
- Navigation sidebar
- Route to different sections

### 4. src/pages/UploadData.tsx
- CSV upload component
- Parse and store sales data
- Display uploaded files list

### 5. src/pages/BundleGenerator.tsx
- Input for bundle item quantity
- Generate bundle recommendations based on sales data
- Display generated bundles
- Save bundles to database

### 6. src/pages/Analytics.tsx
- Charts showing product sales
- Use Recharts for visualization
- Filter by date range

### 7. src/pages/ExportBundles.tsx
- List all saved bundles
- Export bundles as CSV
- Delete bundles

### 8. src/App.tsx
- Update routing for all pages
- Add protected routes

## Implementation Plan
1. Set up Supabase client and database schema
2. Create authentication pages (login/register)
3. Build dashboard layout with navigation
4. Implement upload functionality
5. Create bundle generation logic
6. Build analytics dashboard with charts
7. Add export functionality
8. Test and fix any issues

## Simplifications for MVP
- CSV format only for uploads
- Simple bundle algorithm (top selling products)
- Basic charts (bar/line charts)
- No advanced filtering initially