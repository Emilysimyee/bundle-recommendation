# Supabase Configuration Guide

## Issue: Email Verification Required on First Login

If you're experiencing issues where users must verify their email before logging in, you need to **disable email confirmation** in your Supabase project settings.

### Step-by-Step Instructions

1. **Go to your Supabase Dashboard**
   - Visit: https://supabase.com/dashboard
   - Select your project

2. **Navigate to Authentication Settings**
   - Click on **Authentication** in the left sidebar
   - Click on **Providers**
   - Find and click on **Email**

3. **Disable Email Confirmation**
   - Look for the setting: **"Confirm email"**
   - **Toggle it OFF** (disable it)
   - Click **Save** at the bottom

4. **Alternative: Enable Auto-confirm**
   - If you can't find "Confirm email" toggle, look for:
   - **"Enable email confirmations"** → Set to **OFF**
   - Or **"Auto Confirm"** → Set to **ON**

### What This Does

- **Before:** Users register → Receive confirmation email → Must click link → Can login
- **After:** Users register → Can login immediately (no email confirmation needed)

### Important Notes

- This setting change applies to **new registrations only**
- Existing users who haven't confirmed their email may still need to be manually confirmed
- You can manually confirm existing users in: Authentication → Users → Click user → Confirm user

## Issue: Cannot Delete Account from Frontend

### Why Account Deletion Doesn't Work

Supabase requires **admin privileges** (service role key) to delete user accounts. The frontend only has the **anon key** (public access), which cannot delete users for security reasons.

### Solutions

#### Option 1: Manual Deletion (Current)
Users must:
1. Click "Delete Account" in the app (clears local data and signs out)
2. Contact you to manually delete from Supabase Dashboard
3. You delete the user: Authentication → Users → Find user → Delete

#### Option 2: Backend API (Recommended)
Create a secure backend endpoint:
1. Set up a backend server (Node.js, Python, etc.)
2. Store the **service role key** securely on the backend (never in frontend!)
3. Create an API endpoint that:
   - Verifies the user is authenticated
   - Calls Supabase admin API to delete the user
   - Returns success/failure

#### Option 3: Supabase Edge Functions
1. Create a Supabase Edge Function
2. Use the service role key in the function
3. Call the function from your frontend

### Current Behavior

When users click "Delete Account":
- ✅ Signs them out
- ✅ Clears all local data (receipts, products, bundles, etc.)
- ✅ Shows message explaining the limitation
- ❌ Does NOT delete from Supabase database (requires manual deletion)

## Testing Your Configuration

### Test Email Confirmation is Disabled

1. Register a new account with a test email
2. Check if you can login immediately without clicking any email link
3. If you can login right away → ✅ Configuration is correct
4. If you need to verify email first → ❌ Go back and disable email confirmation

### Test Duplicate Email Prevention

1. Register with an email (e.g., test@example.com)
2. Logout
3. Try to register again with the same email
4. You should see: "This email is already registered. Please login instead."

## Need Help?

If you're still having issues:
1. Double-check the Supabase dashboard settings
2. Try creating a completely new test account
3. Check the browser console for any error messages
4. Verify your `.env` file has the correct Supabase credentials

## Security Note

**Never expose your Supabase service role key in frontend code!**
- ✅ Use it only in backend servers or Edge Functions
- ❌ Never commit it to Git
- ❌ Never include it in frontend environment variables